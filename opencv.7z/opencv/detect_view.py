import cv2
import numpy as np

def order_points(pts):
    # 对四个点进行排序：左上，右上，右下，左下
    rect = np.zeros((4, 2), dtype="float32")  # 修正为正确的括号和dtype
    s = pts.sum(axis=1)
    rect[0] = pts[np.argmin(s)]# 左上
    rect[2] = pts[np.argmax(s)]# 右下
    diff = np.diff(pts, axis=1)
    rect[1] = pts[np.argmin(diff)]# 右上
    rect[3] = pts[np.argmax(diff)]# 左下
    return rect

def four_point_transform(image, pts):
    # 步骤1：坐标点排序（左上、右上、右下、左下）
    rect = order_points(pts)  # 调用排序函数确保点顺序正确
    
    # 步骤2：解构排序后的坐标点
    (tl, tr, br, bl) = rect  # tl:左上角点，tr:右上角点，br:右下角点，bl:左下角点
    
    # 步骤3：计算新图像的宽度（取底边和顶边的最大宽度）
    widthA = np.linalg.norm(br - bl)  # 底边宽度（右下到左下的距离）
    widthB = np.linalg.norm(tr - tl)  # 顶边宽度（右上到左上的距离）
    maxWidth = max(int(widthA), int(widthB))  # 取最大值避免图像被裁剪
    
    # 步骤4：计算新图像的高度（取右侧和左侧的最大高度）
    heightA = np.linalg.norm(tr - br)  # 右侧高度（右上到右下的距离）
    heightB = np.linalg.norm(tl - bl)  # 左侧高度（左上到左下的距离）
    maxHeight = max(int(heightA), int(heightB))  # 取最大值保证完整显示
    
    # 步骤5：构建目标点矩阵（标准矩形形状）
    dst = np.array([
        [0, 0],  # 新图像左上角
        [maxWidth - 1, 0],  # 新图像右上角（-1防止越界）
        [maxWidth - 1, maxHeight - 1],  # 新图像右下角
        [0, maxHeight - 1]],  # 新图像左下角
        dtype="float32")
    
    # 步骤6：计算透视变换矩阵并应用
    M = cv2.getPerspectiveTransform(rect, dst)  # 生成3x3变换矩阵
    warped = cv2.warpPerspective(image, M, (maxWidth, maxHeight))  # 执行透视变换
    
    return warped  # 返回校正后的正视图

def find_largest_contour(image):
    """
    在二值化图像中查找最大轮廓（用于定位主文档区域）
    参数：
        image: 二值化输入图像（通常来自Canny边缘检测或阈值处理）
    返回值：
        numpy数组 - 最大轮廓的点集，形状为(N,1,2)，其中N为轮廓点数
    """
    # RETR_EXTERNAL: 只检测最外层轮廓（忽略嵌套轮廓）
    # CHAIN_APPROX_SIMPLE: 压缩水平/垂直/对角线方向的冗余点
    contours, _ = cv2.findContours(image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    # 通过轮廓面积排序获取最大轮廓（对应main.py中的大黑框检测）
    largest = max(contours, key=cv2.contourArea)
    
    # 颜色过滤扩展提示（当前用于main.py中的黑色边框检测）
    # 如需检测红色框，可添加以下处理：
    # 1. 转换到HSV色彩空间 hsv = cv2.cvtColor(orig_img, cv2.COLOR_BGR2HSV)
    # 2. 定义红色范围 mask = cv2.inRange(hsv, (0,50,20), (5,255,255)) 
    # 3. 与当前轮廓检测结果进行按位与操作
    return largest

def find_square_contours(image, min_area=1000, max_area=100000):
    """
    在二值化图像中查找四边形轮廓（用于定位二维码等方形目标）
    参数：
        image: 二值化输入图像（通常来自阈值处理）
        min_area: 最小轮廓面积，过滤噪点（默认1000像素）
        max_area: 最大轮廓面积，排除过大区域（默认100000像素）
    返回值：
        list[numpy数组] - 四边形轮廓列表，每个元素形状为(4,1,2)
    """
    # RETR_EXTERNAL: 只检测最外层轮廓
    # CHAIN_APPROX_SIMPLE: 压缩冗余轮廓点
    contours, _ = cv2.findContours(image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    squares = []
    for cnt in contours:
        # 计算轮廓面积（用于main.py中的二维码区域筛选）
        area = cv2.contourArea(cnt)
        
        # 面积双重过滤：排除噪点和过大区域
        if min_area < area < max_area:
            # 计算轮廓周长（用于多边形近似）
            peri = cv2.arcLength(cnt, True)
            # 多边形近似：0.04*peri 表示近似精度（周长4%的精度）
            approx = cv2.approxPolyDP(cnt, 0.04 * peri, True)
            # 四边形验证（对应main.py中的二维码黑框检测）
            if len(approx) == 4 and is_rectangle(approx.reshape(4,2),0.8,1.2):
                squares.append(approx)
    return squares  # 返回所有符合条件的四边形轮廓

def sort_squares_by_position(squares):
    # 按左上、右上、左下、右下顺序排序
    centers = [np.mean(sq.reshape(4,2), axis=0) for sq in squares]
    centers = np.array(centers)
    if len(centers) < 4:
        return squares
    # KMeans聚类分上下两行
    from sklearn.cluster import KMeans
    y_coords = centers[:,1].reshape(-1,1)
    kmeans = KMeans(n_clusters=2, n_init=10, random_state=42).fit(y_coords)
    labels = kmeans.labels_
    # 上下行分组
    row1 = [ (c, sq) for c, sq, l in zip(centers, squares, labels) if l == 0 ]
    row2 = [ (c, sq) for c, sq, l in zip(centers, squares, labels) if l == 1 ]
    # 按y均值判断哪行在上
    if np.mean([c[1] for c, _ in row1]) < np.mean([c[1] for c, _ in row2]):
        top, bot = row1, row2
    else:
        top, bot = row2, row1
    # 各自按x排序
    top_sorted = sorted(top, key=lambda x: x[0][0])
    bot_sorted = sorted(bot, key=lambda x: x[0][0])
    # 左上、右上、左下、右下
    result = [top_sorted[0][1], top_sorted[1][1], bot_sorted[0][1], bot_sorted[1][1]]
    return result
def compare_images(img1, img2):
    """使用ORB特征点匹配算法对比图像"""
    # 初始化ORB检测器
    orb = cv2.ORB_create()
    
    # 检测关键点和描述符
    kp1, des1 = orb.detectAndCompute(img1, None)
    kp2, des2 = orb.detectAndCompute(img2, None)
    
    # 创建BFMatcher对象
    bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
    
    # 匹配描述符
    matches = bf.match(des1, des2)
    
    # 根据匹配距离计算相似度（距离越小越相似）
    max_distance = max([m.distance for m in matches]) if matches else 1
    similarity = sum([1 - m.distance/max_distance for m in matches]) / len(matches) if matches else 0
    
    return similarity
def is_rectangle(points,min_a,max_b):
        """验证四边形是否为长方形/正方形"""
        # 方法1：计算最大边长与最小边长比值（容差15%）
        sides = []
        for i in range(4):
            a, b = points[i], points[(i+1)%4]
            sides.append(np.linalg.norm(a - b))
        ratio = max(sides) / min(sides)
        
        # 方法2：计算相邻边角度（允许±10度误差）
        angles = []
        for i in range(4):
            v1 = points[(i+1)%4] - points[i]
            v2 = points[i-1] - points[i]
            cos_theta = np.dot(v1, v2) / (np.linalg.norm(v1)*np.linalg.norm(v2))
            angles.append(np.degrees(np.arccos(cos_theta)))
        
        # 双重验证：长宽比<1.2 且 所有角度在80-100度之间
        return ( min_a < ratio < max_b) and all(80 < ang < 100 for ang in angles)