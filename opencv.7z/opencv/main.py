import cv2
import detect_view
import os
os.environ['OMP_NUM_THREADS'] = '1'  

gray1 = cv2.imread('1.jpg', cv2.IMREAD_GRAYSCALE)
gray2 = cv2.imread('2.jpg', cv2.IMREAD_GRAYSCALE)
def main():
    # 1. 读取原始图片
    img = cv2.imread('image1.jpg')
    # 2. 灰度化和高斯模糊，便于后续边缘检测
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (5,5), 0)
    # 3. 用Canny算法提取边缘
    edged = cv2.Canny(blur, 50, 200)
    # 4. 找到面积最大的轮廓，认为是外部大黑框
    largest = detect_view.find_largest_contour(edged)
    peri = cv2.arcLength(largest, True)  # 计算轮廓周长
    approx = cv2.approxPolyDP(largest, 0.02 * peri, True)  # 多边形逼近
    if len(approx) != 4 or not detect_view.is_rectangle(approx.reshape(4,2),1.1,2):
        print("未找到合规长方形框")
        return
    # 5. 对大黑框做透视变换（扶正），得到正视图
    warped = detect_view.four_point_transform(img, approx.reshape(4,2))
    # 6. 保存扶正后的整体图片
    cv2.imwrite('image_warped.jpg', warped)
    # 7. 对扶正后的图片灰度化、模糊、二值化，便于找小二维码黑框
    warped_gray = cv2.cvtColor(warped, cv2.COLOR_BGR2GRAY)
    warped_blur = cv2.GaussianBlur(warped_gray, (5,5), 0)
    warped_thresh = cv2.adaptiveThreshold(warped_blur, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                          cv2.THRESH_BINARY_INV, 11, 2)
    # 8. 找到所有近似为正方形的轮廓（小二维码黑框）
    squares = detect_view.find_square_contours(warped_thresh)

    # 9. 按面积排序，取最大的4个（假设只有4个二维码）
    squares = sorted(squares, key=cv2.contourArea, reverse=True)[:4]
    if len(squares) != 4:
       warped_gray = cv2.cvtColor(warped, cv2.COLOR_BGR2GRAY)
    # 方法1：特征点匹配
       similarity_orb1 = detect_view.compare_images(warped_gray, gray1)
       similarity_orb2 = detect_view.compare_images(warped_gray, gray2)
    # 方法2：感知哈希
       phash_sim1 = detect_view.compare_images(warped, cv2.imread('1.jpg'))
       phash_sim2 = detect_view.compare_images(warped, cv2.imread('2.jpg'))
       # 相似度阈值
       print(f"ORB特征匹配相似度 | 1号图: {similarity_orb1:.2%} 2号图: {similarity_orb2:.2%}")
       print(f"感知哈希相似度 | 1号图: {phash_sim1:.2%} 2号图: {phash_sim2:.2%}")
       return
    # 10. 按物理位置排序（左上、右上、左下、右下）
    if len(squares) == 4:# 确保至少有4个二维码
        squares = detect_view.sort_squares_by_position(squares)
    erweima = []
    qrDecoder = cv2.QRCodeDetector()
    # 11. 对每个二维码区域做透视变换、保存图片、识别内容
    for i, sq in enumerate(squares):
        rect = detect_view.order_points(sq.reshape(4,2))
        qr_img = detect_view.four_point_transform(warped, rect)
        cv2.imwrite(f'qr_{i+1}_warped.jpg', qr_img)
        data, bbox, _ = qrDecoder.detectAndDecode(qr_img)# 解码
        if data:
            erweima.append(data)
        else:
            erweima.append("")  # 保证每个二维码都有输出
    # 12. 保存所有二维码内容到txt文件
    with open('erweima.txt', 'w', encoding='utf-8') as f:
        for content in erweima:
            f.write(content + '\n')
    for idx, content in enumerate(erweima, 1):
        print(f"二维码{idx}内容: {content if content else '未识别到内容'}")
    print("二维码内容已保存到 erweima.txt")

if __name__ == '__main__':
    main()